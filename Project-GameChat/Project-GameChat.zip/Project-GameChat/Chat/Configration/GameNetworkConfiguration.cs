﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chat.Configration
{
    public static class GameNetworkConfiguration
    {
        public const string ConnectionString =
            "Server=localhost,1433;Database=GameChatNetwork;User Id=sa;Password=SuperStrongPass!23;TrustServerCertificate=true;";
    }
}
