﻿using System;
using System.Numerics;

namespace Generating_0_1_Vectors
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] vector = new int[n];
            Generate(vector, 0);
        }

        static void Generate(int[] vector, int index)
        {
            if (index == vector.Length)
            {
                Console.WriteLine(string.Join("", vector));
                return;
            }

            for (int i = 0; i <= 1; i++)
            {
                vector[index] = i;
                Generate(vector, index + 1);
            }
        }
    }
}
