﻿namespace Combinations_with_Repetition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int k = int.Parse(Console.ReadLine());
            var comb = new List<int>();
            CombineWithRepetition(comb, n, k, 1);
        }
        static void CombineWithRepetition(List<int> comb, int n, int k, int start)
        {
            if (comb.Count == k)
            {
                Console.WriteLine(string.Join(" ", comb));
                return;
            }

            for (int i = start; i <= n; i++)
            {
                comb.Add(i);
                CombineWithRepetition(comb, n, k, i);
                comb.RemoveAt(comb.Count - 1);
            }
        }
    }
}
