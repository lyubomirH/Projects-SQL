﻿namespace Combinations_without_Repetition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int k = int.Parse(Console.ReadLine());
            var comb = new List<int>();
            CombineWithoutRepetition(comb, n, k, 1);

        }
        static void CombineWithoutRepetition(List<int> comb, int n, int k, int start)
        {
            if (comb.Count == k)
            {
                Console.WriteLine(string.Join(" ", comb));
                return;
            }

            for (int i = start; i <= n; i++)
            {
                comb.Add(i);
                CombineWithoutRepetition(comb, n, k, i + 1);
                comb.RemoveAt(comb.Count - 1);
            }
        }
    }
}
